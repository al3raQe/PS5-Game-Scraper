/**
 * PS5 Game Browser — main.js
 * Reads games_ps5_cache.json from Cloudflare R2 CDN.
 * No local scraping — pure read-only viewer.
 *
 * Cache schema (from scraper_ps5.py):
 *   entry.url          — source game page URL (used as ID)
 *   entry.title        — game title
 *   entry.description  — text description
 *   entry.screenshots  — [{role, url, local}]
 *                         role: "cover" | "screenshot_1" | "screenshot_2"
 *                         local: "screenshots_ps5/PPSAXXXXX-slug/filename.jpg"
 *                         CDN path = local with "screenshots_ps5/" prefix stripped
 *   entry.releases     — [{ppsa, region, contributor, password, note, notes,
 *                           game:[{label,url}], updates:[{version,type,label,filehosts:[{label,url}]}]}]
 *   entry.extra        — {ppsa_ids:[{ppsa,region}], ppsa_id, voice, subtitles,
 *                          genre, release_year, table_language, game_size,
 *                          note, youtube_id, ...}
 *   entry.scraped_at   — ISO timestamp
 */

'use strict';

const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path  = require('path');
const https = require('https');
const http  = require('http');
const fs    = require('fs');

// ── CDN config — baked in at build time, not readable from disk ───────────────
// To update these, change the values here and rebuild the exe.
// Users never see this file — it is compiled into the asar bundle.
const CDN_BASE    = 'https://pub-d5f4def955404492b20262ad2a0dc12a.r2.dev';
const IMAGES_BASE = CDN_BASE;
const CACHE_URL   = `${CDN_BASE}/games_ps5_cache.json`;
const UI_CSS_URL  = `${CDN_BASE}/ui_patch.css`;   // upload empty file to disable
const UI_JS_URL   = `${CDN_BASE}/ui_patch.js`;    // upload empty file to disable

// ── In-memory state ───────────────────────────────────────────────────────────
let gamesCache  = null;    // full parsed array from CDN
let cacheByUrl  = null;    // Map<gameUrl, entry>
let lastFetched = 0;

// ── HTTP helper ───────────────────────────────────────────────────────────────
function fetchText(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Too many redirects'));
    const lib = url.startsWith('https://') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'PS5-Game-Browser/1.0' } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        return fetchText(res.headers.location, redirects + 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end',  () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(60_000, () => { req.destroy(); reject(new Error('Timeout: ' + url)); });
  });
}

// ── Image URL resolution ──────────────────────────────────────────────────────
// Cache local paths are like: "screenshots_ps5/PPSA04609-elden-ring-ps5/cover_PPSA04609.jpg"
// CDN bucket root has objects at:          "PPSA04609-elden-ring-ps5/cover_PPSA04609.jpg"
// So we strip the "screenshots_ps5/" prefix and prepend IMAGES_BASE.
function imgUrl(local) {
  if (!local || local === 'dead') return '';
  if (/^https?:\/\//.test(local)) return local;
  const normalised = local
    .replace(/\\/g, '/')                    // Windows backslashes → forward
    .replace(/^screenshots_ps5\//, '');     // strip local prefix
  return IMAGES_BASE + '/' + normalised;
}

// ── Cover extraction from screenshots array ───────────────────────────────────
function findCover(screenshots) {
  const shot = (screenshots || []).find(s => s.role === 'cover');
  return shot ? imgUrl(shot.local || shot.url) : '';
}

function findScreenshots(screenshots) {
  return (screenshots || [])
    .filter(s => s.role !== 'cover')
    .map(s => imgUrl(s.local || s.url))
    .filter(Boolean);
}

// ── Release → version block mapper ───────────────────────────────────────────
// Converts scraper_ps5.py's release objects into the display format that
// index.html's version block renderer expects.
function releaseToVersion(release, idx, extra) {
  const ppsa   = (release.ppsa   || '').trim();
  const region = (release.region || '').trim();

  // Header: "PPSA04609 — EUR" or extract from note or fallback
  let header = '';
  if (ppsa && region) {
    header = `${ppsa} \u2014 ${region}`;
  } else if (ppsa) {
    header = ppsa;
  } else {
    // Try to extract "PP SA XXXXX – REGION" from note (first line)
    const noteLine = (release.note || '').split('\n')[0].trim();
    const m = noteLine.match(/PP\s*SA\s*(\d{5,8})\s*[\u2013\u2014-]\s*(\w+)/i);
    if (m) header = `PPSA${m[1]} \u2014 ${m[2].toUpperCase()}`;
    else   header = `Version ${idx + 1}`;
  }

  // Download rows: game first, then each update/backport entry
  const rows = [];

  // Game row
  if (release.game && release.game.length) {
    rows.push({
      label:   'Game',
      mirrors: release.game.map(g => ({ url: g.url, text: g.label })),
    });
  }

  // Update/backport rows (each update is its own download row)
  if (release.updates && release.updates.length) {
    for (const upd of release.updates) {
      const label = upd.label || (upd.type === 'backport' ? `Backport ${upd.version}` : `Update ${upd.version}`);
      rows.push({
        label,
        mirrors: (upd.filehosts || []).map(f => ({ url: f.url, text: f.label })),
      });
    }
  }

  // DLC row (if present — uncommon in PS5 cache currently)
  if (release.dlc && release.dlc.length) {
    rows.push({
      label:   'DLC',
      mirrors: release.dlc.map(d => ({ url: d.url, text: d.label })),
    });
  }

  // Note: clean up the "Game (v01.017) : Host1 – Host2..." legacy notes line
  // and keep only the meaningful note text
  let note = (release.note || '').trim();
  // Strip "PP SA XXXXX – REGION" first line if that was used as header
  if (/^PP\s*SA\s*\d{5,8}/i.test(note)) {
    note = note.split('\n').slice(1).join('\n').trim();
  }

  return {
    header,
    credit:   (release.contributor || '').trim(),
    rows,
    password: (release.password || '').trim(),
    voice:    idx === 0 ? (extra.voice    || '') : '',   // voice/subs once on first version
    menuSubs: idx === 0 ? (extra.subtitles || '') : '',
    note:     note || '',
  };
}

// ── Data loading ──────────────────────────────────────────────────────────────
async function loadCache(force = false) {
  if (gamesCache && !force) return gamesCache;
  console.log('[data] fetching', CACHE_URL);
  const raw    = await fetchText(CACHE_URL);
  const parsed = JSON.parse(raw);
  if (!Array.isArray(parsed)) throw new Error('games_ps5_cache.json is not an array');
  gamesCache  = parsed;
  cacheByUrl  = new Map(parsed.map(e => [e.url, e]));
  lastFetched = Date.now();
  console.log(`[data] loaded ${gamesCache.length} PS5 entries`);
  return gamesCache;
}

// ── Data mappers ──────────────────────────────────────────────────────────────

// Minimal entry for the grid (cover + title)
function toGridEntry(e) {
  return {
    id:    e.url   || '',
    url:   e.url   || '',
    title: e.title || '',
    image: findCover(e.screenshots),
  };
}

// Full entry for the modal detail view
function toDetailEntry(e) {
  const extra = e.extra || {};

  // Images
  const cover       = findCover(e.screenshots);
  const screenshots = findScreenshots(e.screenshots);

  // PPSA IDs → array of display strings e.g. ["PPSA04609 EUR", "PPSA04610 USA"]
  const ppsaIds = (extra.ppsa_ids || []).map(p => {
    const id  = (p.ppsa   || '').trim();
    const reg = (p.region || '').trim();
    return reg ? `${id} ${reg}` : id;
  }).filter(Boolean);

  const meta = {
    ppsa_ids:  ppsaIds,
    genre:     extra.genre        || '',
    released:  extra.release_year || '',
    language:  extra.table_language || extra.language || '',
    game_size: extra.game_size    || '',
    voice:     extra.voice        || '',
    subtitles: extra.subtitles    || '',
  };

  // Convert releases[] → versions[] (what index.html renders)
  const releases = Array.isArray(e.releases) ? e.releases : [];
  const versions = releases.map((rel, i) => releaseToVersion(rel, i, extra));

  return {
    title:          e.title       || '',
    cover,
    screenshots,
    description:    e.description || '',
    meta,
    versions,
    youtube_id:     extra.youtube_id || '',
    _links_fetched: lastFetched,
  };
}

// ── Electron window ───────────────────────────────────────────────────────────
const ICON_PATH = app.isPackaged
  ? path.join(process.resourcesPath, 'assets', 'icon1.ico')
  : path.join(__dirname, 'assets', 'icon1.ico');

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:     1400,
    height:    900,
    minWidth:  800,
    minHeight: 600,
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    title:           'PS5 Game Browser',
    backgroundColor: '#000000',
    icon:            ICON_PATH,
    show:            false,
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize();
    mainWindow.show();
  });

  if (app.isPackaged) {
    Menu.setApplicationMenu(null);
    mainWindow.removeMenu && mainWindow.removeMenu();
  }

  mainWindow.webContents.on('before-input-event', (_e, input) => {
    if (app.isPackaged) {
      const ctrl  = !!input.control;
      const shift = !!input.shift;
      const key   = input.key ? input.key.toUpperCase() : '';
      if (
        key === 'F11' || key === 'F12' ||
        (ctrl && shift && (key === 'I' || key === 'J' || key === 'C' || key === 'U')) ||
        (!!input.alt && ctrl && key === 'I')
      ) { _e.preventDefault(); }
    } else {
      if (input.type === 'keyDown' && input.key === 'F11')
        mainWindow.setFullScreen(!mainWindow.isFullScreen());
      if (input.type === 'keyDown' && input.key === 'F12')
        _e.preventDefault();
    }
  });

  mainWindow.webContents.on('devtools-opened', () => {
    if (app.isPackaged) mainWindow.webContents.closeDevTools();
  });

  if (app.isPackaged) {
    mainWindow.webContents.on('context-menu', e => e.preventDefault());
  }

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  if (!app.isPackaged && process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── IPC handlers ──────────────────────────────────────────────────────────────

// Grid: array of {id, url, title, image}
ipcMain.handle('load-games-cache', async () => {
  try {
    const data = await loadCache();
    return data.map(toGridEntry);
  } catch (err) {
    console.error('[load-games-cache]', err.message);
    return [];
  }
});

// Modal: full detail for one game by URL
ipcMain.handle('scrape-game-details', async (_e, gameUrl) => {
  try {
    await loadCache();
    const entry = cacheByUrl.get(gameUrl);
    if (!entry) return { error: `Not found: ${gameUrl}` };
    return toDetailEntry(entry);
  } catch (err) {
    console.error('[scrape-game-details]', err.message);
    return { error: err.message };
  }
});

// Reload cache from CDN then return fresh detail
ipcMain.handle('refresh-game-details', async (_e, gameUrl) => {
  try {
    await loadCache(true);
    const entry = cacheByUrl.get(gameUrl);
    if (!entry) return { error: `Not found: ${gameUrl}` };
    return toDetailEntry(entry);
  } catch (err) {
    console.error('[refresh-game-details]', err.message);
    return { error: err.message };
  }
});

// Reload full library from CDN
ipcMain.handle('check-new-games', async () => {
  try {
    await loadCache(true);
    return { ok: true, count: gamesCache ? gamesCache.length : 0 };
  } catch (err) {
    console.error('[check-new-games]', err.message);
    return { ok: false, error: err.message };
  }
});

ipcMain.handle('get-data-source', () => 'remote');
ipcMain.handle('get-proxy-port',  () => null);

ipcMain.handle('open-external', (_e, url) => {
  if (typeof url === 'string' && /^https?:\/\//.test(url)) {
    shell.openExternal(url);
  }
});

// ── Remote UI patches ─────────────────────────────────────────────────────────
// Fetches ui_patch.css / ui_patch.js from CDN URLs defined in config.json.
// Allows pushing CSS/JS UI updates to all users without rebuilding the .exe.
// Files are cached in userData so the app works offline after first load.
ipcMain.handle('get-ui-patches', async () => {
  const cacheDir  = app.getPath('userData');
  const cssCached = path.join(cacheDir, 'ui_patch.css');
  const jsCached  = path.join(cacheDir, 'ui_patch.js');

  async function fetchWithCache(url, cachePath) {
    if (!url) return '';
    try {
      const text = await fetchText(url);
      try { fs.writeFileSync(cachePath, text, 'utf8'); } catch {}
      console.log('[ui-patch] fetched:', url);
      return text;
    } catch (err) {
      console.log('[ui-patch] CDN unavailable, trying local cache:', err.message);
      try { return fs.readFileSync(cachePath, 'utf8'); } catch {}
      return '';
    }
  }

  const [css, js] = await Promise.all([
    fetchWithCache(UI_CSS_URL, cssCached),
    fetchWithCache(UI_JS_URL,  jsCached),
  ]);
  return { css, js };
});
