// PS5 Game Browser — remote patch placeholder
