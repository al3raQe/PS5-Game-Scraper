/**
 * PS5 Game Browser — preload.js
 * Context bridge between main process and renderer.
 * Mirrors PS4 Game Browser preload exactly.
 */
const { contextBridge, ipcRenderer } = require('electron');

// Primary API (matches PS4's gameDB object)
contextBridge.exposeInMainWorld('gameDB', {
  loadGames:      async ()    => await ipcRenderer.invoke('load-games-cache'),
  getDetails:     async (id)  => await ipcRenderer.invoke('scrape-game-details', id),
  refreshDetails: async (id)  => await ipcRenderer.invoke('refresh-game-details', id),
  refreshAll:     async ()    => await ipcRenderer.invoke('check-new-games'),
  getDataSource:  async ()    => await ipcRenderer.invoke('get-data-source'),
  openExternal:   async (url) => await ipcRenderer.invoke('open-external', url),
  getUiPatches:   async ()    => await ipcRenderer.invoke('get-ui-patches'),
});

// PS5-specific alias (used by index.html)
contextBridge.exposeInMainWorld('ps5Scraper', {
  loadPS5GamesCache:   async ()    => await ipcRenderer.invoke('load-games-cache'),
  getGameDetails:      async (id)  => await ipcRenderer.invoke('scrape-game-details', id),
  refreshGameDetails:  async (id)  => await ipcRenderer.invoke('refresh-game-details', id),
  checkNewGames:       async ()    => await ipcRenderer.invoke('check-new-games'),
  getProxyPort:        async ()    => await ipcRenderer.invoke('get-proxy-port'),
});

// Shell / window
contextBridge.exposeInMainWorld('electronShell', {
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
});

// IPC event bus (for progress events etc.)
contextBridge.exposeInMainWorld('electronIPC', {
  on:                 (...args) => ipcRenderer.on(...args),
  removeAllListeners: (...args) => ipcRenderer.removeAllListeners(...args),
});
